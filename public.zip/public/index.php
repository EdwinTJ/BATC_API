<?php require_once('../private/initialize.php'); ?>

<?php include(SHARED_PATH . '/public_header.php'); ?>



<?php $super_hero_image = 'book.jpeg'; ?>

<?php include(SHARED_PATH . '/public_footer.php'); ?>
